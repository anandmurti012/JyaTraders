import BrandSlider from "@/components/slider/BrandSlider"

export default function Brand() {
    return (
        <>
            <div className="brand-aera-five pt-60">
                <div className="container">
                    <BrandSlider />
                </div>
            </div>
        </>
    )
}
