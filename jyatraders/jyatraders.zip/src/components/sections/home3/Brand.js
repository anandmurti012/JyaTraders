import BrandSlider from "@/components/slider/BrandSlider"

export default function Brand() {
    return (
        <>
            <div className="brand-aera-four">
                <div className="container">
                    <div className="brand-item-wrap-two">
                        <BrandSlider />
                    </div>
                </div>
            </div>
        </>
    )
}
